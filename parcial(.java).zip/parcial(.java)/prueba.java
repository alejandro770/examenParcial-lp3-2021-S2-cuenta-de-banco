package cuenta_de_banco;


import cuenta_de_banco.retiros;
import cuenta_de_banco.depositos;

@SuppressWarnings("unused")
public class prueba {

	public static void main(String[] args) {
		
		int opcion;
		
		gen_operaciones o1 = new gen_operaciones ();
		o1.start();
		
		
		System.out.println("--------------------------");
		retiros r1 = new retiros ();
		depositos d1 = new depositos ();
		d1.start();
		r1.start();
		
		historial_movimientos h1 =new historial_movimientos();
		h1.mostrar();
		

	}
	

}