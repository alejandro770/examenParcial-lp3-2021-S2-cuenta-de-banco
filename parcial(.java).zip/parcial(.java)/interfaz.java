package cuenta_de_banco;
// gen_operaciones------------------------------------

public class gen_operaciones extends Thread {
	public final static double lista [][] = new double [2][10];
	double monto_inicial=1000;
	
	/*public operacion(double monto_inicial_) {
		monto_inicial=monto_inicial_;
	}*/
	
	//metodos 
	public void run() {
    	double numero = (int)(Math.random()*10+1);
    	for (int k = 0; k<2; k++) {
    		for (int x=0; x<10; x++) {
    			
    		
    			if(k==0) {//depositos
    				numero = (int)(Math.random()*10+1);
    				lista[k][x]=numero;
    			}
    			if(k==1) {//retiros
    				numero = (int)(Math.random()*10+1);
    				while (numero>=monto_inicial) {
    					numero = (int)(Math.random()*10+1);
    				}
    				numero=numero*-1;
    				lista[k][x]=numero;
    			}
    		}
    	}
    	
    	/*for (int k = 0; k<2; k++) {
    		for (int x=0; x<10; x++) {
    			System.out.println(lista[k][x] );
    		}
    		System.out.println();
    		}*/
	}
}


public class prueba {

	public static void main(String[] args) {
		
		int opcion;
		
		gen_operaciones o1 = new gen_operaciones ();
		o1.start();
		
		
		System.out.println("--------------------------");
		retiros r1 = new retiros ();
		depositos d1 = new depositos ();
		d1.start();
		r1.start();
		
		historial_movimientos h1 =new historial_movimientos();
		h1.mostrar();
		

	}
	

}



//-----------------------------------------------






import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class intefaz extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					intefaz frame = new intefaz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public intefaz() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton iniciar = new JButton("iniciar");
		iniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		iniciar.setBounds(10, 11, 89, 23);
		contentPane.add(iniciar);
	}

}
