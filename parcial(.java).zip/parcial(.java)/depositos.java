package cuenta_de_banco;


public class depositos extends gen_operaciones{
	static int FIN=10;
	
	double[]registro_deposi = new double[FIN];
	
	public void oper_deposi(String str) {
		//super(str);
	}
	
public void run() {
		
		for (int i=0; i<FIN; i++) {
			
			System.out.println("deposito N°"+ (i+1) + " cantidad a depositar "+ "S/"+ lista[0][i]);
			
			monto_inicial=monto_inicial+lista[0][i];
			try {
				sleep((int) (Math.random()*2000));
			} catch (InterruptedException e) {
				System.out.println(e);
			}

		}
		System.out.println("fin depositos");	
	}
	
}