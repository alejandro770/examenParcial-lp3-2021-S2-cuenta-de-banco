package cuenta_de_banco;

public class historial_movimientos extends gen_operaciones {
	
	public void mostrar() {
		for (int k = 0; k<2; k++) {
    		for (int x=0; x<10; x++) {
    			if(x==0 & k==0) {System.out.println ("depositos");}
    			if(x==0 & k==1) {System.out.println ("retiros");}
    			System.out.println(lista[k][x] );
    		}
    		System.out.println();
    		}
	}
	

}
