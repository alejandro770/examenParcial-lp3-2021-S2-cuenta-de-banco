package cuenta_de_banco;

public class gen_operaciones extends Thread {
	public final static double lista [][] = new double [2][10];
	double monto_inicial=1000;
	
	/*public operacion(double monto_inicial_) {
		monto_inicial=monto_inicial_;
	}*/
	
	//metodos 
	public void run() {
    	double numero = (int)(Math.random()*10+1);
    	for (int k = 0; k<2; k++) {
    		for (int x=0; x<10; x++) {
    			
    		
    			if(k==0) {//depositos
    				numero = (int)(Math.random()*10+1);
    				lista[k][x]=numero;
    			}
    			if(k==1) {//retiros
    				numero = (int)(Math.random()*10+1);
    				while (numero>=monto_inicial) {
    					numero = (int)(Math.random()*10+1);
    				}
    				numero=numero*-1;
    				lista[k][x]=numero;
    			}
    		}
    	}
    	
    	/*for (int k = 0; k<2; k++) {
    		for (int x=0; x<10; x++) {
    			System.out.println(lista[k][x] );
    		}
    		System.out.println();
    		}*/
	}
}